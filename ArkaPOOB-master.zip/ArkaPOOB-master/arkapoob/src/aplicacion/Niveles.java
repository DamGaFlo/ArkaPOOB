/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplicacion;

import java.io.Serializable;
import java.lang.reflect.*;
import java.util.*;
import java.util.logging.*;
import math.Vector2D;

public class Niveles implements Serializable{
    
    public final int MAX_FILAS,MAX_COLUMNAS,MAX_LVL = 2;
    private final ArkaPOOB ArkaPOOB;
    private int lvl, plataforma, bloquesIndestructibles;
    private final String[] tiposBloques;
    private double[] probabilidades;
    private ArrayList<Bloque> bloquesDelNivel;
    
    public Niveles(ArkaPOOB ArkaPOOB){
        this.bloquesDelNivel = new ArrayList<>();
        this.MAX_FILAS = ArkaPOOB.getHight()/74;
        this.MAX_COLUMNAS =ArkaPOOB.getWidth()/121; 
        this.ArkaPOOB = ArkaPOOB;
        this.lvl = 0;
        this.plataforma = Base.NORMAL;
        this.tiposBloques = new String[]{"Bloque","BloqueDitto","BloqueDuro","BloqueIndestructible","BloqueNextLvl","BloqueRepelente","BloqueSorpresa","BloqueTeletransportador","BloqueVida"};
        actualizarProbabilidades();
    }
    public Niveles(ArkaPOOB ArkaPOOB, int plataforma){
        this(ArkaPOOB);
        this.plataforma = plataforma;
    }
    
    public void actualizarProbabilidades(){
        this.probabilidades = new double[]{0.3+(lvl/MAX_LVL),0.1+(lvl/MAX_LVL),0.2+(lvl/MAX_LVL),0.0+(lvl/MAX_LVL),0.0+(lvl/MAX_LVL),0.1+(lvl/MAX_LVL),0.3+(lvl/MAX_LVL),0.1+(lvl/MAX_LVL),0.2+(lvl/MAX_LVL)};
    }
    /**
     * Genera un nivel
     * @param filas
     * @param columnas 
     */
    public void genereNivel(int filas, int columnas){
        if(ArkaPOOB.getJugadores().size()>0) for (int i = 0; i< ArkaPOOB.getJugadores().size(); i++) ArkaPOOB.getJugadores().get(i).getBase().setNumEstado(plataforma);
        ArkaPOOB.getBloques().clear(); ArkaPOOB.getBloquesFueraDeJuego().clear();
        if(filas > 0 && filas <= MAX_FILAS && columnas>0 && columnas <= MAX_COLUMNAS){
            int y = ArkaPOOB.getHight()/2-(filas-1)*37,x = ArkaPOOB.getWidth()/2-columnas*60;
            for(int i = 0; i < filas; i++) for(int j=0; j<columnas; j++) {
                try {
                    String nombreClase;
                    nombreClase = "aplicacion."+aleatorioConProbabilidad(0,tiposBloques.length-1,probabilidades);
                    if(nombreClase.equals("aplicacion."+tiposBloques[3])) bloquesIndestructibles++;
                    Class<?> cls = Class.forName(nombreClase);
                    Constructor<?> cons = cls.getDeclaredConstructor(new Class[] {Vector2D.class,ArkaPOOB.class});
                    Object newInstance = cons.newInstance(new Vector2D(x+j*121,y+i*37),ArkaPOOB);
                    ArkaPOOB.getBloques().add((Bloque) newInstance);
                    bloquesDelNivel.add((Bloque)newInstance);
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException ex) {
                    Logger.getLogger(Niveles.class.getName()).log(Level.SEVERE, null, ex);
                }
            }        
        }    
    }
    public void genereNivelEspecial(int filas, int columnas){
        setPlataforma(Base.SHOOTER);
        if(ArkaPOOB.getJugadores().size()>0) for (int i = 0; i< ArkaPOOB.getJugadores().size(); i++) ArkaPOOB.getJugadores().get(i).getBase().setNumEstado(plataforma);
        ArkaPOOB.getBloques().clear(); ArkaPOOB.getBloquesFueraDeJuego().clear();
        if(filas > 0 && filas <= MAX_FILAS && columnas>0 && columnas <= MAX_COLUMNAS){
            int j = columnas;
            for(int i = 0; i < filas && j>=0; i++) 
            {
                int y = ArkaPOOB.getHight()/2-(filas-1)*37,x = ArkaPOOB.getWidth()/2-j*60;
                for(int k = 0; k<j; k++) {
                
                try {
                    String nombreClase;
                    nombreClase = "aplicacion."+aleatorioConProbabilidad(0,tiposBloques.length-1,probabilidades);
                    if(nombreClase.equals("aplicacion."+tiposBloques[3])) bloquesIndestructibles++;
                    Class<?> cls = Class.forName(nombreClase);
                    Constructor<?> cons = cls.getDeclaredConstructor(new Class[] {Vector2D.class,ArkaPOOB.class});
                    Object newInstance = cons.newInstance(new Vector2D(x+k*121,y+i*37),ArkaPOOB);
                    ArkaPOOB.getBloques().add((Bloque) newInstance);
                    bloquesDelNivel.add((Bloque)newInstance);
                    
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException ex) {
                    Logger.getLogger(Niveles.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            j--;}
        }    
    }
    
    /**
     *
     * @param min
     * @param max
     * @param matrizProbabilidad
     * @return
     */
    public String aleatorioConProbabilidad(int min,int max,double[] matrizProbabilidad){
	for (int i=0; i<matrizProbabilidad.length; i++)
            if (Math.random() > 0 && Math.random()<matrizProbabilidad[i])
                return tiposBloques[i];
	return tiposBloques[(int)Math.floor(Math.random()*(max-min+1)+min)];
    }
    /**
     * Pasa de nivel
     */
    public void nextLvl(){
        lvl+=1;
        ArkaPOOB.bolasEnJuego.clear();
        ArkaPOOB.reInicio();
        actualizarProbabilidades();
        genereNivel(MAX_FILAS,MAX_COLUMNAS);
    }
    /**
     * Cambia el nivel
     * @param newLvl 
     */
    public void setLvl(int newLvl){
        lvl = newLvl;
    }
    /**
     * Muestra el nivel actual
     * @return 
     */
    public int getLvl(){
        return lvl+1;
    }
    public void setPlataforma(int newPlataforma){
        plataforma = newPlataforma;
    }
    public void update(){
        if(ArkaPOOB.getBloques().size()<= bloquesIndestructibles) nextLvl();
        else if(getLvl()> MAX_LVL) ArkaPOOB.setTerminado();
    }
    public ArrayList<Bloque> infoNivel(){
        return bloquesDelNivel;
    }
    public int infoBase(){
        return plataforma;
    }

    void setInfoNivel(ArrayList<Bloque> nuevosBloques) {
        bloquesDelNivel = nuevosBloques;
        bloquesIndestructibles = 0;
        for(Bloque b: nuevosBloques) if("BloqueIndestructible".equals(b.getNombre()))bloquesIndestructibles++;
    }
}
