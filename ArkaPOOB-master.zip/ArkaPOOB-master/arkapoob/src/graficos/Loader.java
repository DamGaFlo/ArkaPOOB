package graficos;

import excepciones.Registro;
import java.awt.image.BufferedImage;
import java.io.*;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

public class Loader {
	
    /**
     * Carga imagenes desde una direccion
     * @param path - direccion de la imagen
     * @return 
     */
	public static BufferedImage ImageLoader(String path)
	{
		try {
			return ImageIO.read(new File(path));
		} catch (IOException e) {
			Registro.registre(e);
                        JOptionPane.showMessageDialog(null,e.getMessage(),"Error al Cargar la imagen!!", JOptionPane.WARNING_MESSAGE);
		}
		return null;
	}
	
}    