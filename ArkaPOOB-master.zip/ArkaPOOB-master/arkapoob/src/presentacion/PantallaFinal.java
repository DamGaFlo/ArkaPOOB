/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presentacion;

import excepciones.Registro;
import graficos.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.logging.*;
import javax.swing.*;
import math.Vector2D;


public class PantallaFinal extends JFrame{
    
    private static final int ANCHO = 600, ALTO = 600;
    private final String[] mensaje;
    private JButton salir, nuevoJuego;
    private JPanel panel;
    private ArkaPoobGUI juego;
    private ArrayList<JLabel> palabras;
    
    public PantallaFinal(String mensaje,ArkaPoobGUI juego){
        this.juego = juego;
        this.mensaje = mensaje.toUpperCase().split(",");
        prepareElementos();
        prepareAcciones();
    }
    private void prepareElementos(){
        palabras = new ArrayList<>();
        panel = new JPanel();
        salir = new JButton(new ImageIcon(Loader.ImageLoader("recursos/pantallaFinal/SALIR.png")));
        nuevoJuego = new JButton(new ImageIcon(Loader.ImageLoader("recursos/pantallaFinal/CONTINUAR.png")));
        panel.setLayout(null);
        setUndecorated(true);
        setSize(ANCHO,ALTO);   
        setResizable(false);    
        setLocationRelativeTo(null);                 
        prepareGraficos();
    }

    /**
     * Prepara el canvas para su dibujo
     */
    private void prepareGraficos(){
        panel.setPreferredSize(new Dimension(ANCHO,ALTO));
        panel.setMaximumSize(new Dimension(ANCHO,ALTO));
        panel.setMinimumSize(new Dimension(ANCHO,ALTO));      
        panel.setFocusable(true);
        add(panel);
        draw();
    }
    private void draw(){
        ImageIcon img =  new ImageIcon(Loader.ImageLoader("recursos/pantallaFinal/fondo.jpg"));
        ImageIcon img2 =  new ImageIcon(Loader.ImageLoader("recursos/marcos/marco1.png"));
        JLabel j = new JLabel(img), k = new JLabel(img2);
        j.setBounds(0, 0, ANCHO, ALTO);
        k.setBounds(0,0,ANCHO,ALTO);
        for(int i= 0; i<mensaje.length; i++)drawPalabra(mensaje[i], new Vector2D(ANCHO/2-mensaje[i].length()*9,ALTO/2-((mensaje.length-i)*25)));
        for (int i = 0; i< palabras.size(); i++) panel.add(palabras.get(i));
        setButtons(new Vector2D(3*ANCHO/4-100,ALTO-140),salir,"SALIR");
        setButtons(new Vector2D(ANCHO/4-100,ALTO-140),nuevoJuego,"CONTINUAR");
        
        panel.add(k);
        panel.add(j);
    }
    private void setButtons(Vector2D pos, JButton boton, String path){
        boton.setBounds((int)pos.getX(),(int)pos.getY(),200,40);
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setDisabledIcon(new ImageIcon(Loader.ImageLoader("recursos/pantallaFinal/"+path+".png")));
        boton.setPressedIcon(new ImageIcon(Loader.ImageLoader("recursos/pantallaFinal/"+path+"_O.png")));
        panel.add(boton);
    
    }
    private void drawPalabra(String palabra,Vector2D pos){
        for (int i = 0; i < palabra.length(); i++){
            if(palabra.charAt(i) != ' '){
                try{
                    ImageIcon img= new ImageIcon(Recursos.abecedario.get(palabra.charAt(i)));
                    JLabel j = new JLabel();
                    j.setIcon(img);
                    j.setBounds((int)pos.getX()+(i*19),(int)pos.getY(),19,19);                   
                    palabras.add(j);
                }catch(Exception e){
                    JOptionPane.showMessageDialog(null,"LA PALABRA MANDÓ: "+palabra.charAt(i) ,"Error!!", JOptionPane.WARNING_MESSAGE);
                    Registro.registre(e);
                } 
            }
            
        }
    }
    private void prepareAcciones(){
        salir.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                salir();
            }            
        });
        nuevoJuego.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                nuevoJuego();
            }            
        });
    
    }
    /**
     * define la accion al salir del juego
     */
    private void salir(){
        int confirma = JOptionPane.showConfirmDialog(null, "Desea Volver a la pantalla inicial?", "Exit Confirmation", JOptionPane.YES_NO_OPTION);
        if(confirma== JOptionPane.YES_OPTION) {
                juego.irAPantallaInicio();
                setVisible(false);
        }
    }
    private void nuevoJuego(){
        try {
            String nombreClase = "presentacion."+juego.getClass().getSimpleName();
            Class<?> cls = Class.forName(nombreClase);
            Constructor<?> cons = cls.getDeclaredConstructor(new Class[] {PantallaInicio.class});
            cons.newInstance(juego.pantalla);            
            setVisible(false); 
        } catch (ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(Opciones.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
