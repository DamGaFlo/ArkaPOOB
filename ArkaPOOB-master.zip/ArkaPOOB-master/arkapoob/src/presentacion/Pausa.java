/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presentacion;

import aplicacion.*;
import excepciones.*;
import java.awt.HeadlessException;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import persistencia.*;

/**
 *
 * @author IJuanKhoxD
 */
public class Pausa extends JFrame{
    private static final int ANCHO = 800,LARGO = 400;
    private JLabel nombre;
    private JButton continuar,salir, cargar, salvar, exportar, importar, nuevo;
    private ArkaPoobGUI juego;
    
    public Pausa(ArkaPoobGUI pantalla){
        juego = pantalla;
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(ANCHO,LARGO);  
        setFocusable(true);
        prepareElementos();        
        prepareAcciones();        
	setLocationRelativeTo(null);
    }
    
    private void prepareElementos(){
        setLayout(null);
        setBounds(0, 0, ANCHO, LARGO); 
        cargar = new JButton("Cargar");
        salvar = new JButton("Salvar");
        nuevo = new JButton("Nuevo");
        continuar = new JButton("Continuar");
        exportar = new JButton("Exportar");
        importar = new JButton("Importar");
        nombre = new JLabel(new ImageIcon("recursos/items/Pause.png"));
        nombre.setBounds(ANCHO/2-65,10,130,82);     
        cargar.setBounds(ANCHO/5+40,LARGO/2-25,100,50);       
        salvar.setBounds(2*ANCHO/5+40,LARGO/2-25,100,50);           
        nuevo.setBounds(3*ANCHO/5+40,LARGO/2-25,100,50); 
        exportar.setBounds(4*ANCHO/5+40,LARGO/2-25,100,50);           
        importar.setBounds(0*ANCHO/5+40,LARGO/2-25,100,50); 
        salir = new JButton(new ImageIcon("recursos/PantallaInicio/EXIT.gif"));
        salir.setBounds(3*ANCHO/4-100,LARGO-100,200,126);
        continuar.setBounds(ANCHO/4-100,LARGO-100,200,126);
        salir.setContentAreaFilled(false);
        salir.setBorderPainted(false);         
        JLabel fondo = new JLabel(new ImageIcon("recursos/PantallaInicio/FondoSetup.jpg"));
        fondo.setBounds(0,0,ANCHO,LARGO);
        add(continuar);
        add(importar);
        add(exportar);
        add(nombre);
        add(salir);
        add(nuevo);
        add(cargar);
        add(salvar);
        add(fondo);
    }
    private void prepareAcciones(){
        
        this.addKeyListener(new KeyListener(){
        @Override
        public void keyReleased(KeyEvent ke) {
        if(ke.getKeyChar() == 'p') continuar();
        }
        @Override
        public void keyPressed(KeyEvent ke){
        }
        @Override
        public void keyTyped(KeyEvent ke) {
        }
        
        
        });
                
        salir.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                salir();
            }            
        });
        cargar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                cargar();
            }            
        });
        importar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                importar();
            }            
        });
        exportar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                exportar();
            }            
        });
        salvar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                salvar();
            }            
        });
        nuevo.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                nuevoJuego();
            }            
        });
        continuar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                continuar();
            }            
        });
    }    
    
    private void importar(){
        try{
            JFileChooser seleccion = new JFileChooser();  
            seleccion.setDialogTitle("Importar");
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos txt", "txt");
            seleccion.setFileFilter(filter);
            if(seleccion.showOpenDialog(importar)==JFileChooser.APPROVE_OPTION){
                nuevoJuego();
                ArrayList<Bloque> importar1 = Importar.importar(seleccion.getSelectedFile(), juego.getGame());
                if(importar1 != null)juego.getGame().setBloques(importar1);                
                importar.setFocusable(false);
            }
        }catch(CompilacionExcepcion | HeadlessException e){
            Registro.registre(e);
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error al Importar!!", JOptionPane.WARNING_MESSAGE);
            importar.setFocusable(false);
            this.setFocusable(true);
        }
    }
    
    private void exportar(){
        try{
            JFileChooser seleccion = new JFileChooser();  
            seleccion.setDialogTitle("Exportar");
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos txt", "txt");
            seleccion.setFileFilter(filter);
            if(seleccion.showSaveDialog(exportar)==JFileChooser.APPROVE_OPTION){
                Exportar.exportar(seleccion.getSelectedFile(), juego.getGame());
                continuar();
                exportar.setFocusable(false);
            }
        }catch(CompilacionExcepcion | HeadlessException e){
            Registro.registre(e);
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error al Exportar!!", JOptionPane.WARNING_MESSAGE);
            exportar.setFocusable(false);
            this.setFocusable(true);
        }
    }
    
    private void salvar(){
        try{
            JFileChooser seleccion = new JFileChooser();  
            seleccion.setDialogTitle("Guardar");
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos dat", "dat");
            seleccion.setFileFilter(filter);
            if(seleccion.showSaveDialog(salvar)==JFileChooser.APPROVE_OPTION){
                Salvar.salvar(seleccion.getSelectedFile(), juego.getGame());
                continuar();
                salvar.setFocusable(false);
            }
        }catch(CompilacionExcepcion | HeadlessException e){
            Registro.registre(e);
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error al Salvar!!", JOptionPane.WARNING_MESSAGE);
            salvar.setFocusable(false);
            this.setFocusable(true);
        }
        
    }
    private void cargar(){
        try{
            JFileChooser seleccion = new JFileChooser();               
            seleccion.setDialogTitle("Abrir");
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos dat", "dat");
            seleccion.setFileFilter(filter);           
            if(seleccion.showOpenDialog(cargar)==JFileChooser.APPROVE_OPTION){                
                juego.setJuego(Abrir.abrir(seleccion.getSelectedFile())); 
                continuar();
                cargar.setFocusable(false);
            }
        }catch(CompilacionExcepcion | HeadlessException e){
            Registro.registre(e);
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error al Abrir!!", JOptionPane.WARNING_MESSAGE);
            cargar.setFocusable(false);
            this.setFocusable(true);
        }
    }
    private void nuevoJuego(){               
        continuar();
        juego.generaMundo(); 
        nuevo.setFocusable(false);
        this.setFocusable(true);
    }
    /**
     * define la accion al salir del juego
     */
    private void salir(){
        int confirma = JOptionPane.showConfirmDialog(null, "Desea Volver a la pantalla inicial?", "Exit Confirmation", JOptionPane.YES_NO_OPTION);
        if(confirma== JOptionPane.YES_OPTION) {
                juego.irAPantallaInicio();
                setVisible(false);
        }
        else continuar();
    }
    /**
     * define la accion al salir del juego
     */
    private void continuar(){
        juego.setEnabled(true);
        juego.getGame().pause();
        setVisible(false);
        continuar.setFocusable(false);
        this.setFocusable(true);
    }
}
