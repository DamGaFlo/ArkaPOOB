/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presentacion;

import excepciones.Registro;
import graficos.Recursos;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import math.Vector2D;

public class PantallaInicio extends JFrame{
    
    private static final int ANCHO = 640,LARGO = 480;
    private JButton player1, player2, exit, bSetup;
    private Setup setup = null;    
    private ArrayList<JLabel> palabras;
    private JPanel principal;
    /**
     * Constructor de la pantalla inicial
     */
    public PantallaInicio(){  
        super("ArkaPOOB");         
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE );
        prepareElementos();   
        prepareAcciones();
    }
    
    /**
     * metodo principal
     * @param args 
     */
    public static void main(String[] args){
        PantallaInicio pantallaInicio = new PantallaInicio();        
        pantallaInicio.setVisible(true);  
        
       
                
    }
    
    /**
     * Prepara la pantalla inicial del juego
     */
    private void preparaPantallaInicial(){
        principal = new JPanel();                       
        principal.setLayout(null);                        
        principal.setBounds(0, 0,ANCHO, LARGO);         
        JLabel Arkanoid = new JLabel(new ImageIcon("recursos/PantallaInicio/Arkanoid.png"));      
        JLabel BackGround = new JLabel(new ImageIcon("recursos/PantallaInicio/Fondo.gif"));            
        BackGround.setBounds(0,0,ANCHO, LARGO);                       
        Arkanoid.setBounds(ANCHO/4,30,320,116);
        setButton(new Vector2D(560,30),new Vector2D(50,50),bSetup, principal);
        setButton(new Vector2D(220,150),new Vector2D(200,126),player1, principal);
        setButton(new Vector2D(220,220),new Vector2D(200,126),player2, principal);
        setButton(new Vector2D(220,350),new Vector2D(200,126),exit, principal);         
        drawPalabra("MEJOR PUNTAJE- "+ArkaPoobGUI.MEJOR_PUNTAJE,new Vector2D(30,10));        
        for(int i = 0; i < palabras.size(); i++) principal.add(palabras.get(i));
        principal.add(Arkanoid); 
        principal.add(BackGround);
        add(principal);
    }
    
    public void actualizarPuntaje(){
        if(palabras.size()>0)palabras.clear();
        principal.removeAll();        
        repaint();
        preparaPantallaInicial();
        repaint();
    }
    private void setButton(Vector2D pos,Vector2D dimension, JButton boton,JPanel panel){
        boton.setBounds((int)pos.getX(),(int)pos.getY(),(int)dimension.getX(),(int)dimension.getY());
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        panel.add(boton);
    }
    
    private void drawPalabra(String palabra,Vector2D pos){
        Recursos.init();
        for (int i = 0; i < palabra.length(); i++){
            if(palabra.charAt(i) != ' '){
                try{
                    ImageIcon img= new ImageIcon(Recursos.abecedario.get(palabra.charAt(i)));
                    JLabel j = new JLabel();
                    j.setIcon(img);
                    j.setBounds((int)pos.getX()+(i*19),(int)pos.getY(),19,19);                   
                    palabras.add(j);
                }catch(Exception e){
                    JOptionPane.showMessageDialog(null,e.getMessage(),"Error!!", JOptionPane.WARNING_MESSAGE);
                    Registro.registre(e);
                } 
            }
        }
    }
    /**
     * prepara los elementos del juego
     */
    private void prepareElementos() {         
        setSize(ANCHO,LARGO);
	setResizable(false);
	setLocationRelativeTo(null); 
        palabras = new ArrayList<>();
        setup = new Setup(this);
        bSetup = new JButton(new ImageIcon("recursos/PantallaInicio/Setup.gif"));
        player1 = new JButton(new ImageIcon("recursos/PantallaInicio/1_Player.gif"));
        player2 = new JButton(new ImageIcon("recursos/PantallaInicio/2_Players.gif"));
        exit = new JButton(new ImageIcon("recursos/PantallaInicio/EXIT.gif"));   
        preparaPantallaInicial();
        
    }
    /**
     * Prepara las acciones del juego
     */
    private void prepareAcciones(){
        //prepara boton X de la ventana
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) { 
                salir();
            }
        });
        player1.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                player1();
            }            
        });
        player2.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                player2();
            }            
        });
        bSetup.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                setup();
            }            
        });
        exit.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                salir();
            }            
        });
    }
    
    /**
     * define la accion al salir del juego
     */
    private void salir(){
            int confirma = JOptionPane.showConfirmDialog(null, 
                                            "Esta seguro que desea salir?",
                                            "Exit Confirmation", JOptionPane.YES_NO_OPTION);

            if(confirma== JOptionPane.YES_OPTION) {
                    System.exit(1);
            }
    }
    /**
     * define la accion al seleccionar un jugador
     */
    private void player1() {
        Opciones opciones =  new Opciones(this,"ArkaPoobGUI"); 
        opciones.setVisible(true);
    }
    private void player2() {
        Opciones opciones =  new Opciones(this,"ArkaPoob2pGUI"); 
        opciones.setVisible(true);
    }
    private void setup(){
        setup.setVisible(true);
        setEnabled(false);
    }
}
