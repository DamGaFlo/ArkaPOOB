package presentacion;


import aplicacion.ArkaPOOB2P;
import graficos.Recursos;
import math.Vector2D;

public class ArkaPoob2pGUI extends ArkaPoobGUI {
	
    public ArkaPoob2pGUI(PantallaInicio p){
        super();
        pantalla = p;
    }
    @Override
    public void generaMundo() {
        game = new ArkaPOOB2P();
        game.inicio();
    }
    @Override
    public void score(){
        super.score();
        Vector2D pos = new Vector2D(1050,240);
        drawPalabra("PLAYER_2", pos);
        pos.setY(pos.getY()+20); 
        graficos.drawImage(Recursos.corazon,(int)pos.getX(),(int)pos.getY(),null);
        pos.setX(pos.getX()+20);                
        graficos.drawImage(Recursos.numeros[10],(int)pos.getX(),(int)pos.getY(),null);                             
        pos.setX(pos.getX()+20);
        graficos.drawImage(Recursos.numeros[vidas[1]/10],(int)pos.getX(),(int)pos.getY(),null);
        pos.setX(pos.getX()+20);
        graficos.drawImage(Recursos.numeros[vidas[1]%10],(int)pos.getX(),(int)pos.getY(),null);
        pos.setX(810);
        pos.setY(pos.getY()+190);                
        drawPalabra("SCORE PLAYER_2- "+puntajes[1],pos);

    } 
        
    /**
     * actualiza los valores del juego
     */
    @Override
    public void update(){
        if(game.getTerminado()) { 
            setVisible(false); 
            PantallaFinal pantallaFinal = new PantallaFinal("ENHORABUENA!, HA ACABADO EL JUEGO!!,EL MEJOR PUNTAJE- "+mejorPuntaje(),this); 
            pantallaFinal.setVisible(true);
            stop();
        }
        game.update();
        puntajes = game.getScorePlayers();
        MEJOR_PUNTAJE = MEJOR_PUNTAJE<=mejorPuntaje()?mejorPuntaje():MEJOR_PUNTAJE;
        vidas();
    }
    /**
     * 
     */
    @Override
    public void vidas(){
        if(vidas[0]<=0 || vidas[1]<=0){ 
            setVisible(false); 
            PantallaFinal pantallaFinal = new PantallaFinal("GAME OVER!!, SUERTE A LA PROXIMA, EL MEJOR PUNTAJE- "+mejorPuntaje(),this); 
            pantallaFinal.setVisible(true);
            stop();
        }
        else vidas = game.getVidasPlayers();

    }
}
