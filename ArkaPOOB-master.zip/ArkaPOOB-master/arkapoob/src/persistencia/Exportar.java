/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import aplicacion.ArkaPOOB;
import aplicacion.Bloque;
import excepciones.CompilacionExcepcion;
import java.io.*;
import java.util.ArrayList;


public class Exportar {
    public static void exportar(File archivo, ArkaPOOB juego) throws CompilacionExcepcion{
        if (!archivo.getName().endsWith("txt")) throw new CompilacionExcepcion(CompilacionExcepcion.ARCHIVO_INVALIDO);
        try{
            ArrayList<Bloque> elementos = juego.getInfoLvl();
            BufferedWriter bf=new BufferedWriter(new FileWriter(archivo));
            String linea=juego.getInfoBase()+" "+juego.getLvl();
            bf.write(linea);
            bf.newLine();
            for (int i=0; i<elementos.size();i++){
                if (elementos.get(i)!=null){
                    linea=elementos.get(i).getNombre()+" "+ elementos.get(i).getPosicion().getX()+" "+elementos.get(i).getPosicion().getY();
                    bf.write(linea);
                    bf.newLine();
                }

            }
            bf.close();
        }catch(IOException e){
            throw new CompilacionExcepcion(CompilacionExcepcion.ERROR_EXPORTAR);
			
	}
    }
}
