/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import aplicacion.*;
import excepciones.CompilacionExcepcion;
import excepciones.Registro;
import java.io.*;
import java.lang.reflect.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import math.Vector2D;


public class Importar {
    
    /**
     *
     * @param archivo
     * @param juego
     * @return
     * @throws CompilacionExcepcion
     */
    public static ArrayList<Bloque> importar(File archivo, ArkaPOOB juego) throws CompilacionExcepcion{       
        if (!archivo.getName().endsWith("txt")) throw new CompilacionExcepcion(CompilacionExcepcion.ARCHIVO_INVALIDO);
	
        try{
            BufferedReader br=new BufferedReader(new FileReader(archivo));
            String lineaS = br.readLine();
            String[] linea = lineaS.split(" "); 
            juego.getNivel().setLvl(Integer.parseInt(linea[1])-1);
            juego.getNivel().setPlataforma(Integer.parseInt(linea[0]));
            int numeroDeLinea=0;
            lineaS = br.readLine();
            ArrayList<Bloque> Bloques = new ArrayList<>();
            while (lineaS!=null){
                numeroDeLinea++;
                linea = lineaS.split(" ");            
                compilador(linea,numeroDeLinea,juego);
                double x=Double.parseDouble(linea[1]);
                double y=Double.parseDouble(linea[2]);
                try{										
                    String nombreClase = "aplicacion."+linea[0];
                    Class<?> cls = Class.forName(nombreClase);
                    Constructor<?> cons = cls.getDeclaredConstructor(new Class[] {Vector2D.class,ArkaPOOB.class});
                    Bloques.add((Bloque) cons.newInstance(new Vector2D(x,y),juego));
                    
                }catch(ClassNotFoundException e){
                    throw new CompilacionExcepcion(CompilacionExcepcion.CLASE_NO_ENCONTRADA,numeroDeLinea);
                }catch(NoSuchMethodException | IllegalAccessException | InvocationTargetException | InstantiationException e){
                }
                lineaS=br.readLine();				
            }
            br.close();
            return Bloques;
        }catch(IOException e){
            Registro.registre(e);
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error al Importar!!", JOptionPane.WARNING_MESSAGE);
        }
            return null;

   }
   
   /**
    *Realiza las verificaciones del compilador
    *@param linea Lista de strings con las instrucciones que debe seguir el importador
    *@param numeroDeLinea numero de la linea en el documento
    * @param juego
    * @throws excepciones.CompilacionExcepcion
    */
    public static void compilador(String[] linea,int numeroDeLinea, ArkaPOOB juego) throws CompilacionExcepcion{

            if (linea.length<3) throw new CompilacionExcepcion(CompilacionExcepcion.ERROR_ELEMENTOS,numeroDeLinea);
            if (esNumero(linea[0])) throw new CompilacionExcepcion(CompilacionExcepcion.NOMBRE_NUMERICO,numeroDeLinea);
            if (!esNumero(linea[1]) || !esNumero(linea[2])) throw new CompilacionExcepcion(CompilacionExcepcion.INDICE_NO_NUMERICO,numeroDeLinea);
            if (Double.parseDouble(linea[1])>juego.getWidth()|| Double.parseDouble(linea[2])>juego.getHight()) throw new CompilacionExcepcion(CompilacionExcepcion.FUERA_DEL_LIMITE_M,numeroDeLinea);
            if (Double.parseDouble(linea[1])<0 || Double.parseDouble(linea[2])<0) throw new CompilacionExcepcion(CompilacionExcepcion.FUERA_DEL_LIMITE,numeroDeLinea);
            	
    }
    /**
    *Verifica si un string puede convertirse en numero
    *@param str string a verificar
    @return valor booleano, es true si el string es un numero y false de lo contrario
    */
    public static boolean esNumero(String str){
        try{
            Double.parseDouble(str);
            return true;
        }catch(NumberFormatException e){
            return false;
        }
    }
}
