package excepciones;  

import java.io.IOException;
import java.util.logging.*;

public class Registro{
    public static String nombre="seleccion";
    /**
	*@param e es la exepcion que se quiere registrar
	*/
    public static void registre(Exception e){
        try{
            Logger logger=Logger.getLogger(nombre);
            logger.setUseParentHandlers(false);
            FileHandler file=new FileHandler(nombre+".log",true);
            file.setFormatter(new SimpleFormatter());
            logger.addHandler(file);
            logger.log(Level.SEVERE,e.toString(),e);
            file.close();
        }catch (IOException | SecurityException oe){
            oe.printStackTrace();
            System.exit(0);
        }
    }
}
    
