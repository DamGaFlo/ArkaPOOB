/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *
 * @author IJuanKhoxD
 */
public class CompilacionExcepcion extends Exception {
    public final static String ERROR_SALVAR = "Se ha presentado un error al guardar el archivo";
    public final static String ERROR_ABRIR = "Error durante la apertura del archivo";
    public final static String ERROR_EXPORTAR = "Error durante la exportacion del archivo";
    public final static String ERROR_IMPORTAR = "Error durante la importacion del archivo";
    public static final String ARCHIVO_INVALIDO = "Archivo no compatible";
        
    public final static String ERROR_ELEMENTOS = "El archivo que trata de importar no tiene el numero correcto de instrucciones";
    public final static String NOMBRE_NUMERICO = "El archivo posee un nombre incorrecto formado por numeros";
    public final static String FUERA_DEL_LIMITE = "El archivo se encuentra fuera de las dimensiones permitidas";    
    public final static String FUERA_DEL_LIMITE_M = "El archivo se encuentra fuera de las dimensiones MAXIMAS permitidas";
    public final static String INDICE_NO_NUMERICO = "El archivo posee caracteres incorrectos para una posicion numerica";
    public final static String CLASE_NO_ENCONTRADA = "El archivo contiene clases inexistentes en el programa";
    public CompilacionExcepcion(String message){		
            super(message);
    }
    public CompilacionExcepcion(String message,int line){		
            super("En la linea "+line+" "+message);
    }
}
